//
//  Constant.h
//  CQtralDemo
//
//  Created by 科文 on 2017/4/13.
//  Copyright © 2017年 ZdSoft. All rights reserved.
//
#ifdef SYNTHESIZE_CONSTS

# define CONST(name,value) NSString* const name=@ value
#else
#define CONST(name,value) extern NSString* const name
#endif

//#ifndef __OPTIMIZE__
//#define NSLog(...) NSLog(__VA_ARGS__)
//#else
//#define NSLog(...){}
//#endif



#import <Foundation/Foundation.h>

CONST(URL_BASE_SERVER, "http://istour.isaced.com/api/");

@interface Constant : NSObject


@end
