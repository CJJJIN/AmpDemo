//
//  MapTestViewController.h
//  CQtralDemo
//
//  Created by 科文 on 2017/5/2.
//  Copyright © 2017年 ZdSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MAMapKit/MAMapKit.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <AMapSearchKit/AMapSearchKit.h>

@interface AMapTestViewController : UIViewController

@property (nonatomic,retain) NSString *destinationPoint;//目标点
@property (nonatomic,retain) NSString *dsTitle;//目的地名
@end
