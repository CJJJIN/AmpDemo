//
//  AllDetailViewController.h
//  CQtralDemo
//
//  Created by 科文 on 2017/4/24.
//  Copyright © 2017年 ZdSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AllDetailViewController : UIViewController{
    
}

@end
