//
//  AppDelegate.h
//  CQtralDemo
//
//  Created by CLL on 2017/4/11.
//  Copyright © 2017年 ZdSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

