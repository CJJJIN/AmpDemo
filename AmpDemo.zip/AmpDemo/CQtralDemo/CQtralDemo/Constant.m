//
//  Constant.m
//  CQtralDemo
//
//  Created by 科文 on 2017/4/13.
//  Copyright © 2017年 ZdSoft. All rights reserved.
//
#define SYNTHESIZE_CONSTS

#import "Constant.h"

@implementation Constant

@end
